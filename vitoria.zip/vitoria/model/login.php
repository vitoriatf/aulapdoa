<?php
    include_once "../factory/conexao.php";
    $email = $_POST["cxemail"];
    $senha = $_POST["cxsenha"];
    $query = "select email, senha, perfil from tbusuarios WHERE email = '$email' AND senha = '$senha' ";
    $result = mysqli_query ($conn,$query);
    $linha = mysqli_fetch_assoc($result);
    $perfil = $linha['perfil'];

    if(mysqli_num_rows ($result) > 0){
        if($perfil == 'aluno'){
            header ('location:../view/telaaluno.php');
        } else if($perfil == 'professor'){
            header ('location:../view/telaprofessor.php');
        } else if($perfil == 'diretor'){
            header ('location:../view/teladiretor.php');
        }

    }
    else{
        echo "E-mail ou senha errados!";
    };
?>
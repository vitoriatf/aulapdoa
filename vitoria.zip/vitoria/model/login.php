<?php
    require_once("../factory/conexao.php");
    if($_POST["cxcarro"] !=""){
        $conn = new caminho();
        $query = "insert into tbcarros(carro,fabricante,valor,ano) values(:nome,:fabri,:valor,:ano)";
        $cadastrar = $conn->getConn()->prepare($query);

        $cadastrar->bindParam(':nome', $_POST['cxcarro'],PDO::PARAM_STR);
        $cadastrar->bindParam(':fabri', $_POST['cxfabricante'],PDO::PARAM_STR);

        $cadastrar->execute();
        if($cadastrar->rowCount()){
            echo "Dados cadastrados com sucesso!";
        }else{
            echo "Dados não cadastrados";
        }
    
    }else{
        echo "Campos incompletos, favor preencher";
    }
?>
<?php
    include_once "../factory/conexao.php";
    
    SESSION_START();

    $email = $_POST ["cxemail"];
    $senha = $_POST ["cxsenha"];
    $sql = "select * from tbusuario WHERE email = '$email' AND senha = '$senha' ";
    $result = mysqli_query ($conn,$sql);
    if(mysqli_num_rows ($result) > 0){
        $_SESSION ["email"] = $email;
        $_SESSION ["senha"] = $senha;
        header ('location:../view/menu.php');
    }
    else{
        echo "E-mail ou senha errados!";
        unset($_SESSION["email"]);
        unset($_SESSION["senha"]);
    };
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=], initial-scale=1.0">
    <title>Diretor</title>
    <style type="text/css">
        body{
            background-color: green;
        }
    </style>
</head>
<body>
    <h1>Tela do diretor</h1>
</body>
</html>
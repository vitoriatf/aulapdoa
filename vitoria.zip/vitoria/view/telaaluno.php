<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=], initial-scale=1.0">
    <title>Aluno</title>
    <style type="text/css">
        body{
            background-color: blue;
        }
    </style>
</head>
<body>
    <h1>Tela do aluno</h1>
</body>
</html>